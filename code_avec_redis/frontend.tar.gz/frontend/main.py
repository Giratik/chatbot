import streamlit as st
import requests
import uuid
import time
import os

# --- CONFIGURATION ---
LOGO_PATH = "ressource/Eau_de_Paris_bleu.svg.png"
API_URL = os.environ.get("API_URL", "http://backend:8000")

model_vlm_choix = "mistral-small3.2:24b"
selected_model = "mistral-small3.2:24b"
#selected_model = "mistral:latest"
#model_vlm_choix = "mistral-small3.2:24b"

selected_context_size = 16384
#selected_context_size = 8192

selected_temperature = 0.4

# --- FONCTIONS DE SESSION ---
# Vérifie que le fichier n'a pas déjà été traité
#if "processed_files" not in st.session_state:
if "processed_files" :
    st.session_state.processed_files = []

def new_session():
    # Création d'une session pour l'utilisateur à laquelle est rattaché la conversation du chat
    # On force un identifiant fixe pour le test
    #st.session_state.session_id = "utilisateur_test_absolu"
    st.session_state.session_id = str(uuid.uuid4())
    st.session_state.messages = []
    st.session_state.processed_files = []

def reset_and_rerun():
    # fonction pour réinitialiser le chat, équivaut à recharger sa page avec f5
    new_session()
    st.rerun()

# ---------------------------------------------------------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------------------------------------------------------



# --- INTERFACE ---
st.set_page_config(page_title="Chatbot EDP - Dev", page_icon="💧", layout="wide")

# (Décommenter si le chemin du logo est correct)
if os.path.exists(LOGO_PATH):
    st.logo(LOGO_PATH) 

if "session_id" not in st.session_state:
    new_session()

if st.sidebar.button("Nouvelle session", use_container_width=True):
    reset_and_rerun()
st.title("Chatbot EDP - Version de Dev")

# 1. AFFICHAGE DE L'HISTORIQUE
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["display_content"])

user_input = st.chat_input(
    "Votre message...",
    accept_file="multiple",
    file_type= None,
    accept_audio = False,
)

# 2. TRAITEMENT DE L'ENTRÉE UTILISATEUR
if user_input :
    file_list = ""
    conversation_contexte = ""
    
    # --- A. GESTION DES FICHIERS (REQUÊTE HTTP) ---
    if hasattr(user_input, "files") and user_input.files:
        i=0
        for fichier_joint in user_input.files:
            #if fichier_joint.name not in st.session_state.processed_files:
            st.session_state.processed_files.append(fichier_joint.name)
            fichier_joint = user_input.files[i]
            file_list += f"📎 **Fichier joint :** {fichier_joint.name}\n"
        
            # On prépare le fichier et les paramètres pour l'API
            files = {"file": (fichier_joint.name, fichier_joint.getvalue(), fichier_joint.type)}
            data = {"modele": model_vlm_choix}
            
            # On envoie le fichier à FastAPI
            reponse = requests.post(f"{API_URL}/upload_fichier", files=files, data=data)
            
            if reponse.status_code == 200:
                contenu_extrait = reponse.json().get("contenu", "Fichier vide.")
                conversation_contexte += f"📄 **Contexte du fichier ({fichier_joint.name}) :**\n{contenu_extrait}\n\n---\n\n"
            else:
                st.error(f"Erreur d'analyse pour {fichier_joint.name}")

    # --- B. GESTION DU TEXTE ---
    user_text = ""
    if hasattr(user_input, "text"):
        user_text = user_input.text
    elif isinstance(user_input, str):
        user_text = user_input
                
    instruction = user_text if user_text else "Peux-tu analyser ce(s) document(s) et m'en faire un résumé ?"

    # display_content : vu par l'utilisateur / content : vu par l'IA
    display_text = f"{file_list}\n{instruction}" if file_list else instruction
    llm_text = f"{conversation_contexte} **Instruction de l'utilisateur :**\n{instruction}"

    st.session_state.messages.append({
        "role": "user", 
        "display_content": display_text,     
        "content": llm_text      
    })

    with st.chat_message("user"):
        st.markdown(display_text)

    # --- C. APPEL DU CHATBOT (REQUÊTE HTTP EN STREAMING) ---
    with st.chat_message("assistant"):
        start_time = time.time()

        payload = {
            "session_id": st.session_state.session_id,
            "message": llm_text,
            "modele": selected_model,
            "temperature": selected_temperature,
            "context_size": selected_context_size
        }
#
        # Fonction génératrice pour lire le flux venant de FastAPI
        def lire_flux_api():
            # On se connecte à FastAPI avec l'option stream=True
            with requests.post(f"{API_URL}/chat", json=payload, stream=True) as r:
                r.raise_for_status() # Lève une erreur si la connexion échoue
                for chunk in r.iter_content(chunk_size=1024):
                    if chunk:
                        yield chunk.decode("utf-8")

        # Streamlit affiche le texte en temps réel
        full_response = st.write_stream(lire_flux_api())
        
        end_time = time.time() # Arrêt du chronomètre
        elapsed_time = end_time - start_time # Calcul de la durée

        #prompt_t = metrics.get('prompt_tokens', 0)
        #comp_t = metrics.get('completion_tokens', 0)
        
        # Affichage discret du temps pris en dessous du message
        #st.caption(f"Généré en {elapsed_time:.2f} secondes")
        st.caption(
            f"⏱️ **Temps** : {elapsed_time:.2f}s"
            #f"📥 **Prompt** : {prompt_t} tokens | "
            #f"📤 **Réponse** : {comp_t} tokens | "
            #f"⚡ **Vitesse** : {comp_t / elapsed_time:.1f} t/s"
        )

    # On sauvegarde la réponse de l'IA dans l'historique
    st.session_state.messages.append({
        "role": "assistant", 
        "display_content": full_response,
        "content": full_response
    })