from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import List, Dict, Any
import asyncio
import io
import redis
import json
import sys
import os

# Import de tes fonctions locales existantes
from backend.ollama_client import inferring_ollama
from backend.file_type_action import analyser_contenu_fichier

# Création de l'application FastAPI
app = FastAPI(title="API EDP Chatbot")

# --- CONNEXION REDIS ---
client_redis = redis.Redis(
    host=os.environ.get("REDIS_HOST", "redis"),
    port=int(os.environ.get("REDIS_PORT", 6379)),
    db=0,
    decode_responses=True # Récupère directement du texte (UTF-8)
)


# On autorise 1 seule analyse d'image à la fois
verrou_vlm_image = asyncio.Semaphore(1)

# Définition du format de données attendu pour le chat
#class ChatRequest(BaseModel):
#    messages: List[Dict[str, Any]]
#    modele: str
#    temperature: float
#    context_size: int

# --- NOUVEAU FORMAT ATTENDU REDIS ---
class ChatRequest(BaseModel):
    session_id: str
    message: str # Seulement le nouveau message
    modele: str
    temperature: float
    context_size: int


# --- ROUTE 1 : ANALYSE DE FICHIER ---
@app.post("/upload_fichier")
async def traiter_fichier(file: UploadFile = File(...), modele: str = Form(...)):
    """Reçoit un fichier de Streamlit, l'analyse, et renvoie le texte extrait."""
    try:
        ## 1. On lit la totalité du fichier envoyé par le réseau
        file_bytes = await file.read()
        ## 2. ASTUCE : On crée un faux objet Streamlit en mémoire vive
        faux_fichier_streamlit = io.BytesIO(file_bytes)
        faux_fichier_streamlit.name = file.filename      # On lui redonne son nom
        faux_fichier_streamlit.type = file.content_type  # On lui redonne son format (ex: application/pdf)
        
        async with verrou_vlm_image:
            contenu = analyser_contenu_fichier(faux_fichier_streamlit, modele)
        
        return {"nom_fichier": file.filename, "contenu": contenu}
        
    except Exception as e:
        # Le print permettra de voir l'erreur exacte dans le terminal du backend
        print(f"Erreur backend lors de l'analyse : {str(e)}") 
        return {"erreur": str(e)}

# --- ROUTE 2 : GÉNÉRATION DU CHAT (STREAMING) ---
@app.post("/chat")
async def generer_chat(requete: ChatRequest):
    """Reçoit l'historique, injecte le prompt système et renvoie un flux texte."""

    # 1. Récupération de l'historique dans Redis
    historique_json = client_redis.get(requete.session_id)
    if historique_json:
        historique = json.loads(historique_json)
    else:
        historique = []

    # 2. Ajout de la nouvelle instruction de l'utilisateur
    historique.append({"role": "user", "content": requete.message})
    
    # 1. Injection de la logique métier (Prompt Système)
    #system_prompt = "Tu es un assistant professionnel qui répond aux utilisateurs de manière claire, concise et informative en français. Tu fournis des réponses précises et utiles en fonction des questions posées."
    
    # 3. Injection du System Prompt (juste pour Ollama, pas sauvegardé en DB)
    system_prompt = "Tu es un assistant professionnel qui répond aux utilisateurs de manière claire, concise et informative en français."
    messages_pour_ollama = [{"role": "system", "content": system_prompt}] + historique

    #conversation_complete = []
    #for i, msg in enumerate(requete.messages):
    #    if i == 0 and msg["role"] == "user":
    #        # On fusionne le système avec le tout premier message
    #        conversation_complete.append({
    #            "role": "user", 
    #            "content": f"{system_prompt}\n\nVoici ma demande : {msg['content']}"
    #        })
    #    else:
    #        conversation_complete.append(msg)

    # 2. Création du générateur (Streaming)
    def stream_generator():
        texte_genere =""
        # Appel à ton modèle local
        for chunk in inferring_ollama(
            messages=messages_pour_ollama,
            model=requete.modele,
            temperature=requete.temperature,
            stream=True,
            context_size=requete.context_size
        ):
            texte_genere += chunk
            yield chunk
        # 5. SAUVEGARDE FINALE DANS REDIS
        # Une fois le streaming terminé, on ajoute la réponse de l'IA à l'historique
        historique.append({"role": "assistant", "content": texte_genere})
        # On écrase l'ancienne valeur dans Redis avec le nouvel historique complet
        client_redis.set(requete.session_id, json.dumps(historique))
        
    # 3. Renvoi des données en temps réel à Streamlit
    return StreamingResponse(stream_generator(), media_type="text/plain")