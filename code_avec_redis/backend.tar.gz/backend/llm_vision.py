import os
import ollama
from ollama import Client

# 1. On récupère l'URL (si elle n'est pas dans Docker, on met ton IP par défaut)
# On utilise une variable personnalisée OLLAMA_URL pour être sûr
URL_OLLAMA = os.environ.get("OLLAMA_URL", "http://10.75.12.5:11434")
client = Client(host=URL_OLLAMA)
def analyse_image(image_bytes, prompt, model):
    """
    Envoie une image au modèle vlm via Ollama et retourne l'analyse.
    """

    print(f"⏳ Analyse de l'image en cours avec {model}...")
    
    try:
        reponse = client.chat(
            #qwen3-vl:8b est plus rapide que llava:13b, mais moins performant sur les tâches complexes, un peu la flemme de recopier du code mais reconnaît bien les formes. ==> du mal avec le texte 
            # utile pour du global understanding, mais pas pour des analyses très détaillées.
            # ministral-3:14b pour l'instant le plus performant pour reconnaître du texte mais très susceptible aux hallucinations pour les formes.
            # llama3.2-vision:11b à oublier
            # llava:13b à oublier pour l'instant, il est très lent et ne semble pas plus performant que les autres sur les tâches simples.
            # llava:7b à oublier, trop faible.
            model=model,
            options={
                "temperature": 0.4,
                "num_ctx": 16384,
            },
            messages=[
                {
                    'role': 'user',
                    'content': prompt,
                    'images': [image_bytes]
                }
            ]
        )
        
        return reponse['message']['content']

    except Exception as e:
        return f"❌ Une erreur s'est produite lors de la communication avec Ollama : {e}\n(Vérifie que l'application Ollama est bien lancée en arrière-plan)."
