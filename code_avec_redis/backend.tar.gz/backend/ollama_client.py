from urllib import response
import os
import ollama
from ollama import Client

# 1. On récupère l'URL (si elle n'est pas dans Docker, on met ton IP par défaut)
# On utilise une variable personnalisée OLLAMA_URL pour être sûr
URL_OLLAMA = os.environ.get("OLLAMA_URL", "http://10.75.12.5:11434")
client = Client(host=URL_OLLAMA)

def inferring_ollama(messages, model, temperature=0.4, stream=True, stats_dict=None, context_size=32768):
    # Appel à l'API avec le paramètre stream
    response = client.chat(
        model=model,
        messages=messages,
        options={
            "temperature": temperature,
            "num_ctx": context_size
        },
        stream=stream 
    )
    
    for chunk in response:
        # Si c'est le dernier morceau et qu'on a fourni un dictionnaire
        if chunk.get('done') and stats_dict is not None:
            # On récupère les tokens du prompt (entrée)
            stats_dict['prompt_tokens'] = chunk.get('prompt_eval_count', 0)
            # On récupère les tokens de la génération (sortie)
            stats_dict['completion_tokens'] = chunk.get('eval_count', 0)
            
        # On yield uniquement le texte pour ne pas perturber Streamlit
        if 'message' in chunk and 'content' in chunk['message']:
            yield chunk['message']['content']