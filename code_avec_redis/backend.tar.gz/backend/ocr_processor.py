import pytesseract
from pdf2image import convert_from_bytes
from PIL import Image
import io

def process_file_with_ocr(uploaded_file):
    """
    Convertit le fichier uploadé en texte via Tesseract OCR.
    """
    text_content = ""
    file_type = uploaded_file.type

    try:
        # Si c'est un PDF
        if "pdf" in file_type:
            # Convertit chaque page du PDF en image
            images = convert_from_bytes(uploaded_file.read())
            for i, image in enumerate(images):
                text_content += f"\n--- Page {i+1} ---\n"
                # lang='fra+eng' permet de bien lire le français et l'anglais
                text_content += pytesseract.image_to_string(image, lang='fra+eng')
                
        # Si c'est déjà une image
        elif "image" in file_type:
            image = Image.open(uploaded_file)
            text_content += pytesseract.image_to_string(image, lang='fra+eng')
            
        else:
            return "Format non supporté."
            
    except Exception as e:
        return f"Erreur lors de la lecture OCR : {str(e)}"

    return text_content